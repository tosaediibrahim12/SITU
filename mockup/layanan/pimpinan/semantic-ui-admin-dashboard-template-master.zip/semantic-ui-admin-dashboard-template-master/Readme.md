# 🙈 🙉 🙊 Semantic UI - Sample Admin Dashboard Template

## 😃 Click here for the 👉 [💥LIVE DEMO](https://frontendfunn.github.io/semantic-ui-admin-dashboard-template/)

---

![preview](./images/preview.png)

# 👉 Subscribe to My Channel [💙❤️Youtube❤️💙](https://www.youtube.com/channel/UCpOHt5d6GG-mvo-_pU06rhQ?sub_confirmation=1)

Made with ❤️ - by [FrontEndFunn](https://www.youtube.com/channel/UCpOHt5d6GG-mvo-_pU06rhQ?sub_confirmation=1)
